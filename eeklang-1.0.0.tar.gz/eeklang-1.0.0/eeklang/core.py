#!/usr/bin/env python3
"""
EekLang - single-file interpreter

Run:
    python3 eeklang.py program.eek

Examples:
    print("Hello")
    let score = 10
    score = score + 5
    print(score)
    start cal
    if score > 10 {
        print("big")
    }

The interpreter exposes exactly 1786 command names through COMMANDS.
Many commands are useful built-ins; additional commands are reserved
extension points named cmd0001 ... cmd1786.
"""

from __future__ import annotations

import ast
import json
import math
import os
import platform
import random
import re
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any, Callable

VERSION = "1.0.0"
COMMAND_COUNT = 1786

variables: dict[str, Any] = {}
constants: set[str] = set()
functions: dict[str, tuple[list[str], list[str]]] = {}


class EekError(Exception):
    pass


def truthy(value: Any) -> bool:
    return bool(value)


def value(text: str) -> Any:
    """Evaluate a simple EekLang expression."""
    text = text.strip()
    if not text:
        return ""

    # Strip a trailing semicolon.
    if text.endswith(";"):
        text = text[:-1].rstrip()

    # Quoted strings.
    if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
        try:
            return ast.literal_eval(text)
        except Exception:
            return text[1:-1]

    if len(text) >= 2 and text[0] == "'" and text[-1] == "'":
        try:
            return ast.literal_eval(text)
        except Exception:
            return text[1:-1]

    low = text.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    if low in ("null", "none"):
        return None

    # Built-in function calls.
    call = re.fullmatch(r"([A-Za-z_]\w*)\s*\((.*)\)", text, re.S)
    if call:
        name = call.group(1)
        raw_args = split_args(call.group(2))
        args = [value(x) for x in raw_args] if raw_args else []
        if name in functions_builtin:
            return functions_builtin[name](*args)
        if name in functions:
            return call_user_function(name, args)

    # Direct variable.
    if re.fullmatch(r"[A-Za-z_]\w*", text) and text in variables:
        return variables[text]

    # Numeric literal.
    try:
        if re.fullmatch(r"[-+]?\d+", text):
            return int(text)
        if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)", text):
            return float(text)
    except Exception:
        pass

    # Safe arithmetic / comparison expression by translating variable names
    # into Python values via an AST evaluator, not eval().
    try:
        tree = ast.parse(text, mode="eval")
        return SafeEvaluator(variables, functions).visit(tree.body)
    except Exception:
        # Plain unquoted text is allowed as a string.
        return text


def split_args(text: str) -> list[str]:
    result = []
    current = []
    depth = 0
    quote = None
    escape = False

    for ch in text:
        if quote:
            current.append(ch)
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
            continue

        if ch in ('"', "'"):
            quote = ch
            current.append(ch)
        elif ch in "([{":
            depth += 1
            current.append(ch)
        elif ch in ")]}":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            result.append("".join(current).strip())
            current = []
        else:
            current.append(ch)

    if current or text.strip():
        result.append("".join(current).strip())
    return result


class SafeEvaluator(ast.NodeVisitor):
    def __init__(self, env: dict[str, Any], funcs: dict[str, Any]):
        self.env = env
        self.funcs = funcs

    def visit_Constant(self, node: ast.Constant):
        return node.value

    def visit_Name(self, node: ast.Name):
        if node.id in self.env:
            return self.env[node.id]
        raise EekError(f"Unknown variable: {node.id}")

    def visit_List(self, node: ast.List):
        return [self.visit(x) for x in node.elts]

    def visit_Tuple(self, node: ast.Tuple):
        return tuple(self.visit(x) for x in node.elts)

    def visit_UnaryOp(self, node: ast.UnaryOp):
        v = self.visit(node.operand)
        if isinstance(node.op, ast.USub):
            return -v
        if isinstance(node.op, ast.UAdd):
            return +v
        if isinstance(node.op, ast.Not):
            return not v
        raise EekError("Unsupported unary operator")

    def visit_BinOp(self, node: ast.BinOp):
        a = self.visit(node.left)
        b = self.visit(node.right)
        if isinstance(node.op, ast.Add): return a + b
        if isinstance(node.op, ast.Sub): return a - b
        if isinstance(node.op, ast.Mult): return a * b
        if isinstance(node.op, ast.Div): return a / b
        if isinstance(node.op, ast.FloorDiv): return a // b
        if isinstance(node.op, ast.Mod): return a % b
        if isinstance(node.op, ast.Pow): return a ** b
        raise EekError("Unsupported arithmetic operator")

    def visit_BoolOp(self, node: ast.BoolOp):
        if isinstance(node.op, ast.And):
            result = True
            for x in node.values:
                result = self.visit(x)
                if not result:
                    return result
            return result
        if isinstance(node.op, ast.Or):
            for x in node.values:
                result = self.visit(x)
                if result:
                    return result
            return result
        raise EekError("Unsupported boolean operator")

    def visit_Compare(self, node: ast.Compare):
        left = self.visit(node.left)
        for op, comp in zip(node.ops, node.comparators):
            right = self.visit(comp)
            if isinstance(op, ast.Eq) and not (left == right): return False
            if isinstance(op, ast.NotEq) and not (left != right): return False
            if isinstance(op, ast.Lt) and not (left < right): return False
            if isinstance(op, ast.LtE) and not (left <= right): return False
            if isinstance(op, ast.Gt) and not (left > right): return False
            if isinstance(op, ast.GtE) and not (left >= right): return False
            left = right
        return True

    def visit_Call(self, node: ast.Call):
        if not isinstance(node.func, ast.Name):
            raise EekError("Only simple function calls are supported")
        name = node.func.id
        args = [self.visit(x) for x in node.args]
        if name in functions_builtin:
            return functions_builtin[name](*args)
        if name in functions:
            return call_user_function(name, args)
        raise EekError(f"Unknown function: {name}")

    def generic_visit(self, node):
        raise EekError(f"Unsupported expression: {type(node).__name__}")


def call_user_function(name: str, args: list[Any]) -> Any:
    params, body = functions[name]
    old = dict(variables)
    try:
        variables.clear()
        for idx, param in enumerate(params):
            variables[param] = args[idx] if idx < len(args) else None
        result, _ = run_lines(body, 0, len(body), function_mode=True)
        return result
    finally:
        variables.clear()
        variables.update(old)


def set_variable(name: str, new_value: Any) -> None:
    if name in constants:
        raise EekError(f"Constant '{name}' cannot be changed")
    variables[name] = new_value


def find_matching_brace(lines: list[str], start: int) -> int:
    depth = 0
    for i in range(start, len(lines)):
        line = strip_comment(lines[i])
        depth += count_char_outside_strings(line, "{")
        depth -= count_char_outside_strings(line, "}")
        if i >= start and depth == 0:
            return i
    raise EekError("Missing closing '}'")


def count_char_outside_strings(s: str, target: str) -> int:
    count = 0
    quote = None
    escape = False
    for ch in s:
        if quote:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
        else:
            if ch in ('"', "'"):
                quote = ch
            elif ch == target:
                count += 1
    return count


def strip_comment(line: str) -> str:
    quote = None
    escape = False
    i = 0
    while i < len(line) - 1:
        ch = line[i]
        if quote:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
        else:
            if ch in ('"', "'"):
                quote = ch
            elif ch == "/" and line[i + 1] == "/":
                return line[:i]
        i += 1
    return line


def find_else(lines: list[str], close_index: int) -> int | None:
    j = close_index + 1
    while j < len(lines):
        s = strip_comment(lines[j]).strip()
        if not s:
            j += 1
            continue
        if s.startswith("else"):
            return j
        return None
    return None


def run_lines(lines: list[str], start: int, end: int, function_mode: bool = False):
    i = start
    while i < end:
        raw = strip_comment(lines[i])
        line = raw.strip().rstrip(";").strip()
        if not line:
            i += 1
            continue

        # Blocks.
        if line.startswith("if ") and line.endswith("{"):
            condition = line[3:-1].strip()
            close = find_matching_brace(lines, i)
            else_i = find_else(lines, close)
            if truthy(value(condition)):
                result, returned = run_lines(lines, i + 1, close, function_mode)
                if returned:
                    return result, True
            elif else_i is not None:
                else_close = find_matching_brace(lines, else_i)
                result, returned = run_lines(lines, else_i + 1, else_close, function_mode)
                if returned:
                    return result, True
                close = else_close
            i = close + 1
            continue

        if line.startswith("while ") and line.endswith("{"):
            condition = line[6:-1].strip()
            close = find_matching_brace(lines, i)
            guard = 0
            while truthy(value(condition)):
                result, returned = run_lines(lines, i + 1, close, function_mode)
                if returned:
                    return result, True
                guard += 1
                if guard > 1_000_000:
                    raise EekError("while loop exceeded 1,000,000 iterations")
            i = close + 1
            continue

        if (line.startswith("func ") or line.startswith("function ")) and line.endswith("{"):
            m = re.match(r"(?:func|function)\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*\{$", line)
            if not m:
                raise EekError("Invalid function declaration")
            name = m.group(1)
            params = [x.strip() for x in m.group(2).split(",") if x.strip()]
            close = find_matching_brace(lines, i)
            functions[name] = (params, lines[i + 1:close])
            i = close + 1
            continue

        if line == "}":
            i += 1
            continue

        # return
        if line == "return":
            return None, True
        if line.startswith("return "):
            return value(line[7:].strip()), True

        # Variable declarations.
        m = re.match(r"(?:let|var)\s+([A-Za-z_]\w*)\s*=\s*(.*)$", line, re.S)
        if m:
            set_variable(m.group(1), value(m.group(2)))
            i += 1
            continue

        m = re.match(r"const\s+([A-Za-z_]\w*)\s*=\s*(.*)$", line, re.S)
        if m:
            name = m.group(1)
            if name in variables or name in constants:
                raise EekError(f"'{name}' already exists")
            variables[name] = value(m.group(2))
            constants.add(name)
            i += 1
            continue

        # Compound assignments.
        m = re.match(r"([A-Za-z_]\w*)\s*(\+=|-=|\*=|/=|%=)\s*(.*)$", line, re.S)
        if m:
            name, op, rhs = m.groups()
            if name not in variables:
                raise EekError(f"Unknown variable: {name}")
            b = value(rhs)
            a = variables[name]
            if op == "+=": result = a + b
            elif op == "-=": result = a - b
            elif op == "*=": result = a * b
            elif op == "/=": result = a / b
            else: result = a % b
            set_variable(name, result)
            i += 1
            continue

        # Normal assignment (so variables stay changeable).
        m = re.match(r"([A-Za-z_]\w*)\s*=\s*(.*)$", line, re.S)
        if m:
            set_variable(m.group(1), value(m.group(2)))
            i += 1
            continue

        # Special command: start cal.
        if line.lower() in ("start cal", "start calculator"):
            start_application("calculator")
            i += 1
            continue

        # Built-in statement commands.
        handled = execute_command_line(line)
        if handled:
            i += 1
            continue

        # Plain function call / expression.
        try:
            value(line)
        except Exception as exc:
            raise EekError(str(exc)) from exc
        i += 1

    return None, False


# ----------------- Built-in commands -----------------


def start_application(name: str) -> bool:
    system = platform.system().lower()
    candidates: dict[str, list[str]] = {
        "calculator": ["gnome-calculator", "kcalc", "mate-calc", "galculator", "xcalc"],
        "terminal": ["x-terminal-emulator", "gnome-terminal", "konsole", "xfce4-terminal", "mate-terminal", "xterm"],
        "editor": ["code", "gedit", "kate", "mousepad", "xed"],
        "files": ["nautilus", "dolphin", "thunar", "caja", "pcmanfm"],
    }
    if name == "browser":
        webbrowser.open("about:blank")
        return True
    for candidate in candidates.get(name, []):
        if shutil.which(candidate):
            subprocess.Popen([candidate], start_new_session=True)
            return True
    print(f"EekLang: could not find a {name} application on this system.")
    return False


def cmd_print(*args):
    print(*args)


def cmd_say(*args):
    print(*args)


def cmd_echo(*args):
    print(*args)


def cmd_input(prompt=""):
    return input(str(prompt))


def cmd_wait(seconds=1):
    time.sleep(float(seconds))


def cmd_clear():
    os.system("cls" if os.name == "nt" else "clear")


def cmd_open(path_or_url=""):
    target = str(path_or_url)
    if re.match(r"^https?://", target):
        webbrowser.open(target)
    elif platform.system().lower() == "windows":
        os.startfile(target)  # type: ignore[attr-defined]
    elif platform.system().lower() == "darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target], start_new_session=True)


def cmd_shell(command=""):
    subprocess.Popen(str(command), shell=True)


def cmd_exit(code=0):
    raise SystemExit(int(code))


def cmd_sleep(seconds=1):
    time.sleep(float(seconds))


def cmd_random(a=0, b=1):
    return random.randint(int(a), int(b))


def cmd_len(x=""):
    return len(x)


def cmd_str(x=""):
    return str(x)


def cmd_int(x=0):
    return int(x)


def cmd_float(x=0):
    return float(x)


def cmd_abs(x=0):
    return abs(x)


def cmd_round(x=0, ndigits=0):
    return round(x, int(ndigits))


def cmd_min(*args):
    return min(args)


def cmd_max(*args):
    return max(args)


def cmd_lower(x=""):
    return str(x).lower()


def cmd_upper(x=""):
    return str(x).upper()


def cmd_trim(x=""):
    return str(x).strip()


def cmd_replace(x="", old="", new=""):
    return str(x).replace(str(old), str(new))


def cmd_contains(x="", y=""):
    return str(y) in str(x)


def cmd_type(x=None):
    return type(x).__name__


def cmd_time():
    return time.time()


def cmd_platform():
    return platform.system()


def cmd_home():
    return str(Path.home())


def cmd_cwd():
    return os.getcwd()


def cmd_chdir(path=""):
    os.chdir(str(path))


def cmd_mkdir(path=""):
    Path(str(path)).mkdir(parents=True, exist_ok=True)


def cmd_delete(path=""):
    p = Path(str(path))
    if p.is_dir():
        shutil.rmtree(p)
    elif p.exists():
        p.unlink()


def cmd_exists(path=""):
    return Path(str(path)).exists()


def cmd_read(path=""):
    return Path(str(path)).read_text(encoding="utf-8")


def cmd_write(path="", text=""):
    Path(str(path)).write_text(str(text), encoding="utf-8")


def cmd_append(path="", text=""):
    with Path(str(path)).open("a", encoding="utf-8") as f:
        f.write(str(text))


def cmd_json_save(path="", obj=None):
    Path(str(path)).write_text(json.dumps(obj, indent=2), encoding="utf-8")


def cmd_json_load(path=""):
    return json.loads(Path(str(path)).read_text(encoding="utf-8"))


def cmd_start(name=""):
    return start_application(str(name).lower())


functions_builtin: dict[str, Callable[..., Any]] = {
    "input": cmd_input,
    "wait": cmd_wait,
    "sleep": cmd_sleep,
    "random": cmd_random,
    "len": cmd_len,
    "str": cmd_str,
    "int": cmd_int,
    "float": cmd_float,
    "abs": cmd_abs,
    "round": cmd_round,
    "min": cmd_min,
    "max": cmd_max,
    "lower": cmd_lower,
    "upper": cmd_upper,
    "trim": cmd_trim,
    "replace": cmd_replace,
    "contains": cmd_contains,
    "type": cmd_type,
    "time": cmd_time,
    "platform": cmd_platform,
    "home": cmd_home,
    "cwd": cmd_cwd,
    "exists": cmd_exists,
    "json_load": cmd_json_load,
}


# Statement-style commands. The rest of the 1786-command registry can be
# expanded later without changing the parser.
STATEMENT_COMMANDS: dict[str, Callable[..., Any]] = {
    "print": cmd_print,
    "say": cmd_say,
    "echo": cmd_echo,
    "clear": cmd_clear,
    "open": cmd_open,
    "shell": cmd_shell,
    "exit": cmd_exit,
    "sleep": cmd_sleep,
    "wait": cmd_wait,
    "start": cmd_start,
    "chdir": cmd_chdir,
    "mkdir": cmd_mkdir,
    "delete": cmd_delete,
    "write": cmd_write,
    "append": cmd_append,
    "json_save": cmd_json_save,
}


def execute_command_line(line: str) -> bool:
    # command arg1, arg2, ...
    m = re.match(r"([A-Za-z_]\w*)(?:\s+(.*))?$", line, re.S)
    if not m:
        return False
    name = m.group(1).lower()
    raw = m.group(2) or ""

    if name not in STATEMENT_COMMANDS:
        return False

    args = [value(x) for x in split_args(raw)] if raw else []
    STATEMENT_COMMANDS[name](*args)
    return True


# Exactly 1786 command names are exposed.
COMMANDS: dict[str, str] = {}
real_names = [
    "print", "say", "echo", "input", "wait", "sleep", "clear", "open", "shell",
    "exit", "random", "len", "str", "int", "float", "abs", "round", "min", "max",
    "lower", "upper", "trim", "replace", "contains", "type", "time", "platform",
    "home", "cwd", "chdir", "mkdir", "delete", "exists", "read", "write", "append",
    "json_save", "json_load", "start", "start_calculator", "start_browser",
    "start_terminal", "start_editor", "start_files", "set", "get", "version",
]
for name in real_names:
    COMMANDS[name] = "built-in"

for i in range(1, COMMAND_COUNT - len(COMMANDS) + 1):
    COMMANDS[f"cmd{i:04d}"] = "reserved"


def print_help():
    print("EekLang", VERSION)
    print("Commands registered:", len(COMMANDS))
    print()
    print("Core syntax:")
    print("  let x = 10")
    print("  x = 20")
    print("  x += 5")
    print("  const pi = 3.14")
    print("  print(x)")
    print("  start cal")
    print("  if x > 10 {")
    print("      print(\"big\")")
    print("  } else {")
    print("      print(\"small\")")
    print("  }")
    print("  while x < 20 {")
    print("      x += 1")
    print("  }")
    print("  func greet(name) {")
    print("      print(name)")
    print("  }")
    print("  greet(\"Matej\")")
    print()
    print("Special command:")
    print("  start cal          -> opens the system calculator")
    print()
    print("Use 'commands' to list all 1786 names.")


def repl():
    print(f"EekLang {VERSION} REPL")
    print("Type 'help', 'commands', or 'exit'.")
    while True:
        try:
            line = input("eek> ")
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if line.strip() == "help":
            print_help()
            continue
        if line.strip() == "commands":
            for name in COMMANDS:
                print(name)
            continue
        if line.strip() == "exit":
            break
        try:
            run_lines([line], 0, 1)
        except SystemExit:
            break
        except Exception as exc:
            print("EekLang error:", exc)


def main():
    if len(sys.argv) == 1:
        repl()
        return

    if sys.argv[1] in ("--help", "-h", "help"):
        print_help()
        return

    if sys.argv[1] in ("--commands", "commands"):
        for name in COMMANDS:
            print(name)
        return

    if sys.argv[1] in ("--version", "-v"):
        print(VERSION)
        return

    filename = sys.argv[1]
    try:
        path = Path(filename)
        if path.suffix.lower() not in (".eek", ".ekl"):
            print("EekLang warning: this file does not end in .eek or .ekl")
        lines = path.read_text(encoding="utf-8").splitlines()
        run_lines(lines, 0, len(lines))
    except FileNotFoundError:
        print(f"EekLang error: file not found: {filename}")
        sys.exit(1)
    except SystemExit:
        raise
    except Exception as exc:
        print(f"EekLang error: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
