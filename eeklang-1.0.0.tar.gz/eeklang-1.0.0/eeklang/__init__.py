"""EekLang programming language."""
from .core import main, VERSION

__version__ = VERSION
__all__ = ["main", "__version__"]
