# EekLang

EekLang is a small beginner-friendly programming language.

## Run

```bash
eek program.eek
```

or:

```bash
python -m eeklang program.eek
```

## Example

```text
let score = 10
score = 20
say(score)
start cal
```
